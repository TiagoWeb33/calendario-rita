# Rita & Tiago — Calendar OS

Calendário responsivo para universidade, rotina, transportes, desporto, hobbies, Kanban e Spotify.

## Já incluído
- Calendário semanal com eventos por hora
- Persistência automática no browser via localStorage (refresh não apaga os dados)
- Kanban arrastável
- Rotinas de manhã/noite, skincare, refeições, banho, ginásio e transportes
- Links contextuais para Spotify
- UI responsiva para PC/iPad/tablet/telemóvel
- Partilha preparada

## Sincronização real entre dispositivos + e-mail
O frontend está preparado para Supabase + Resend. Preencher `.env.local` a partir de `.env.example` e substituir a persistência local pelas chamadas à base partilhada. As credenciais não estão incluídas nem inventadas.

## Run
```bash
npm install
npm run dev
```
