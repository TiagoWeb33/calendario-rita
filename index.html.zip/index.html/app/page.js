'use client';
import {useEffect,useMemo,useState} from 'react';
import {CalendarDays,CheckCircle2,ChevronLeft,ChevronRight,Clock3,Dumbbell,Footprints,Heart,LayoutDashboard,Mail,Menu,Music2,Plus,Share2,ShowerHead,Sparkles,Sun,TrainFront,Utensils,X} from 'lucide-react';

const LS='rita-tiago-calendar-v1';
const dayNames=['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'];
const dayLong=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'];
const categories=[['Estudo','study'],['Universidade','uni'],['Ginásio','gym'],['Rotina','routine'],['Transporte','transport'],['Lazer','leisure']];
const colors={study:'#8b5cf6',uni:'#2563eb',gym:'#ef4444',routine:'#10b981',transport:'#f59e0b',leisure:'#ec4899'};
const spotify={study:'https://open.spotify.com/search/deep%20focus',gym:'https://open.spotify.com/search/gym%20workout',morning:'https://open.spotify.com/search/morning%20chill',leisure:'https://open.spotify.com/search/chill%20evening'};

function isoDate(d){return d.toISOString().slice(0,10)}
function addDays(s,n){const d=new Date(s+'T12:00:00'); d.setDate(d.getDate()+n); return isoDate(d)}
function mondayOf(s){const d=new Date(s+'T12:00:00'); const day=d.getDay()||7; d.setDate(d.getDate()-day+1); return isoDate(d)}
function timeToMin(t){const [h,m]=t.split(':').map(Number);return h*60+m}
function fmtRange(a,b){return `${a}–${b}`}

const seed=[
 {id:'wake',date:addDays(mondayOf(isoDate(new Date())),0),start:'07:15',end:'07:40',title:'Rotina de manhã',cat:'routine',icon:'sun'},
 {id:'skin',date:addDays(mondayOf(isoDate(new Date())),0),start:'07:40',end:'08:00',title:'Skincare + preparar saída',cat:'routine',icon:'sparkle'},
 {id:'bus',date:addDays(mondayOf(isoDate(new Date())),0),start:'08:10',end:'08:45',title:'Autocarro → universidade',cat:'transport',icon:'bus'},
 {id:'class',date:addDays(mondayOf(isoDate(new Date())),0),start:'09:00',end:'11:00',title:'Aulas / estudo',cat:'uni',icon:'book'},
 {id:'lunch',date:addDays(mondayOf(isoDate(new Date())),0),start:'12:30',end:'13:15',title:'Almoço',cat:'routine',icon:'food'},
 {id:'study',date:addDays(mondayOf(isoDate(new Date())),0),start:'14:00',end:'16:00',title:'Bloco de estudo focado',cat:'study',icon:'book'},
 {id:'gym',date:addDays(mondayOf(isoDate(new Date())),0),start:'18:00',end:'19:15',title:'Ginásio',cat:'gym',icon:'gym'},
 {id:'shower',date:addDays(mondayOf(isoDate(new Date())),0),start:'19:20',end:'19:45',title:'Banho + skincare',cat:'routine',icon:'shower'},
 {id:'dinner',date:addDays(mondayOf(isoDate(new Date())),0),start:'20:00',end:'20:45',title:'Jantar',cat:'routine',icon:'food'},
 {id:'cal',date:addDays(mondayOf(isoDate(new Date())),0),start:'21:30',end:'22:00',title:'Planeamento do dia seguinte',cat:'routine',icon:'check'},
];

function Icon({name,size=16}){const p={size,strokeWidth:1.8}; if(name==='sun')return <Sun {...p}/>;if(name==='sparkle')return <Sparkles {...p}/>;if(name==='bus')return <TrainFront {...p}/>;if(name==='gym')return <Dumbbell {...p}/>;if(name==='shower')return <ShowerHead {...p}/>;if(name==='food')return <Utensils {...p}/>;if(name==='check')return <CheckCircle2 {...p}/>;return <Clock3 {...p}/>}

export default function Home(){
 const today=isoDate(new Date());
 const [week,setWeek]=useState(mondayOf(today));
 const [events,setEvents]=useState(seed);
 const [tasks,setTasks]=useState([{id:1,t:'Entregar trabalho de História',s:'today'},{id:2,t:'Comprar produtos skincare',s:'next'},{id:3,t:'Marcar treino',s:'doing'},{id:4,t:'Preparar mochila',s:'done'}]);
 const [tab,setTab]=useState('calendar'); const [selected,setSelected]=useState(null); const [showAdd,setShowAdd]=useState(false); const [share,setShare]=useState(false); const [notice,setNotice]=useState('');
 useEffect(()=>{try{const x=JSON.parse(localStorage.getItem(LS)); if(x){setEvents(x.events||seed);setTasks(x.tasks||[])} }catch{}},[]);
 useEffect(()=>{localStorage.setItem(LS,JSON.stringify({events,tasks,savedAt:Date.now()}))},[events,tasks]);
 const days=useMemo(()=>Array.from({length:7},(_,i)=>addDays(week,i)),[week]);
 const weekLabel=`${new Date(days[0]+'T12:00:00').toLocaleDateString('pt-PT',{day:'numeric',month:'short'})} — ${new Date(days[6]+'T12:00:00').toLocaleDateString('pt-PT',{day:'numeric',month:'short',year:'numeric'})}`;
 function moveTask(id,status){setTasks(t=>t.map(x=>x.id===id?{...x,s:status}:x))}
 function addEvent(e){e.id=crypto.randomUUID();setEvents(v=>[...v,e]);setShowAdd(false);}
 function del(id){setEvents(v=>v.filter(e=>e.id!==id));setSelected(null)}
 return <main className="shell">
   <aside className="sidebar">
    <div className="brand"><div className="brandMark">R</div><div><b>Rita & Tiago</b><span>Weekly life OS</span></div></div>
    <nav>
      {[["calendar","Calendário",CalendarDays],["kanban","Kanban",LayoutDashboard],["routines","Rotinas",Sun]].map(([id,label,I])=><button className={tab===id?'navBtn active':'navBtn'} onClick={()=>setTab(id)} key={id}><I size={18}/>{label}</button>)}
    </nav>
    <div className="sideCard"><div className="miniTitle">ESTA SEMANA</div><div className="progress"><span style={{width:'68%'}}/></div><b>68% organizada</b><small>Boa. Mantém o ritmo.</small></div>
    <div className="sideBottom"><button className="shareGhost" onClick={()=>setShare(true)}><Share2 size={17}/> Partilhar com Rita</button><small>Dados guardados automaticamente</small></div>
   </aside>
   <section className="content">
    <header className="topbar"><div className="mobileBrand"><div className="brandMark">R</div><b>Rita & Tiago</b></div><div className="topRight"><div className="couple"><span>Tiago</span><span className="dot">•</span><span>Rita</span></div><button className="iconBtn" onClick={()=>setShowAdd(true)}><Plus size={19}/></button><button className="primary" onClick={()=>setShowAdd(true)}><Plus size={17}/> Novo evento</button></div></header>
    {tab==='calendar'&&<>
      <div className="hero"><div><div className="eyebrow">SEMANA A DOIS · UNIVERSIDADE</div><h1>Boa semana, Rita. <span>✨</span></h1><p>Organiza aulas, estudo, treino, refeições, transportes e tempo para vocês sem perder o controlo.</p></div><button className="spotify" onClick={()=>window.open(spotify.study,'_blank')}><Music2 size={17}/> Spotify desta semana</button></div>
      <div className="calendarToolbar"><div className="weekNav"><button onClick={()=>setWeek(addDays(week,-7))}><ChevronLeft size={19}/></button><strong>{weekLabel}</strong><button onClick={()=>setWeek(addDays(week,7))}><ChevronRight size={19}/></button></div><button className="todayBtn" onClick={()=>setWeek(mondayOf(today))}>Hoje</button></div>
      <div className="calendarWrap"><div className="calHead"><div></div>{days.map((d,i)=><div key={d} className={'dayHead '+(d===today?'today':'')}><span>{dayNames[i]}</span><b>{new Date(d+'T12:00:00').getDate()}</b></div>)}</div><div className="gridBody">
       <div className="hours">{Array.from({length:14},(_,i)=><span key={i}>{String(i+7).padStart(2,'0')}:00</span>)}</div>
       {days.map(d=><div className="dayCol" key={d}>{Array.from({length:13},(_,i)=><div className="hourLine" key={i}/>) }
        {events.filter(e=>e.date===d).map(e=>{const top=(timeToMin(e.start)-420)/60*68; const height=Math.max(42,(timeToMin(e.end)-timeToMin(e.start))/60*68);return <button key={e.id} className="event" style={{top, height, borderLeftColor:colors[e.cat]}} onClick={()=>setSelected(e)}><span className="eventTime">{e.start}</span><b>{e.title}</b><small>{fmtRange(e.start,e.end)}</small></button>})}
       </div>)}
      </div></div>
      <section className="below"><div className="panel"><div className="panelHead"><div><h2>Hoje</h2><span>{new Date(today+'T12:00:00').toLocaleDateString('pt-PT',{weekday:'long',day:'numeric',month:'long'})}</span></div><button onClick={()=>setShowAdd(true)}><Plus size={16}/></button></div>{events.filter(e=>e.date===today).sort((a,b)=>a.start.localeCompare(b.start)).slice(0,6).map(e=><div className="timeline" key={e.id}><span>{e.start}</span><div className="tlDot" style={{background:colors[e.cat]}}></div><div><b>{e.title}</b><small>{e.end} · {e.cat}</small></div></div>)}</div>
      <div className="panel"><div className="panelHead"><div><h2>Momento certo</h2><span>música por contexto</span></div><Music2 size={18}/></div>{[['study','Estudo','Deep Focus'],['gym','Ginásio','Workout Energy'],['morning','Manhã','Morning Chill'],['leisure','Noite','Chill Evening']].map(([k,a,b])=><button className="musicRow" onClick={()=>window.open(spotify[k],'_blank')} key={k}><span className="musicIcon"><Music2 size={16}/></span><div><b>{a}</b><small>{b}</small></div><span>↗</span></button>)}</div></section>
      </>}
    {tab==='kanban'&&<Kanban tasks={tasks} moveTask={moveTask} addTask={()=>{const t=prompt('Nome da tarefa?'); if(t)setTasks(x=>[...x,{id:Date.now(),t,s:'today'}])}}/>}
    {tab==='routines'&&<Routines spotify={spotify}/>} 
   </section>
   {selected&&<div className="modalShade" onMouseDown={()=>setSelected(null)}><div className="modal" onMouseDown={e=>e.stopPropagation()}><div className="modalTop"><span className="badge" style={{background:colors[selected.cat]}}>{selected.cat}</span><button onClick={()=>setSelected(null)}><X/></button></div><h2>{selected.title}</h2><p>{selected.date} · {selected.start}–{selected.end}</p><div className="modalActions"><button className="danger" onClick={()=>del(selected.id)}>Apagar</button><button className="primary" onClick={()=>setSelected(null)}>Fechar</button></div></div></div>}
   {showAdd&&<AddModal days={days} onClose={()=>setShowAdd(false)} onAdd={addEvent}/>} 
   {share&&<ShareModal onClose={()=>setShare(false)} onNotice={setNotice}/>} 
   {notice&&<div className="toast">{notice}</div>}
 </main>
}

function AddModal({days,onClose,onAdd}){const [f,setF]=useState({date:days[0],start:'09:00',end:'10:00',title:'',cat:'study'});return <div className="modalShade"><div className="modal"><div className="modalTop"><h2>Novo evento</h2><button onClick={onClose}><X/></button></div><div className="form"><label>Título<input value={f.title} onChange={e=>setF({...f,title:e.target.value})} placeholder="Ex.: Aula de Matemática"/></label><label>Dia<select value={f.date} onChange={e=>setF({...f,date:e.target.value})}>{days.map(d=><option key={d} value={d}>{new Date(d+'T12:00:00').toLocaleDateString('pt-PT',{weekday:'long',day:'numeric',month:'short'})}</option>)}</select></label><div className="row"><label>Começa<input type="time" value={f.start} onChange={e=>setF({...f,start:e.target.value})}/></label><label>Termina<input type="time" value={f.end} onChange={e=>setF({...f,end:e.target.value})}/></label></div><label>Categoria<select value={f.cat} onChange={e=>setF({...f,cat:e.target.value})}>{categories.map(([n,v])=><option key={v} value={v}>{n}</option>)}</select></label></div><div className="modalActions"><button onClick={onClose}>Cancelar</button><button className="primary" disabled={!f.title} onClick={()=>onAdd(f)}>Guardar</button></div></div></div>}

function ShareModal({onClose,onNotice}){return <div className="modalShade"><div className="modal"><div className="modalTop"><h2>Partilhar o calendário</h2><button onClick={onClose}><X/></button></div><p className="shareCopy">O calendário está preparado para um modo partilhado Tiago + Rita. A memória local já funciona entre refreshes neste dispositivo.</p><div className="shareBox"><Heart size={17}/><div><b>Rita & Tiago</b><small>Espaço privado · planeamento semanal</small></div></div><button className="primary wide" onClick={()=>{navigator.clipboard?.writeText(window.location.href);onNotice('Link copiado. Para sincronização entre dispositivos, ligue a base de dados partilhada nas variáveis de ambiente.');onClose()}}><Share2 size={17}/> Copiar link</button><small className="note">Para sincronização real em vários dispositivos e notificações por e-mail, o projeto inclui pontos de integração para Supabase + Resend.</small></div></div>}

function Kanban({tasks,moveTask,addTask}){const cols=[['today','Hoje'],['doing','A fazer'],['next','Próximo'],['done','Concluído']];return <div className="sectionPage"><div className="sectionHead"><div><div className="eyebrow">DRAG & DROP</div><h1>Kanban</h1><p>Arrasta as tarefas entre colunas e mantém a semana leve.</p></div><button className="primary" onClick={addTask}><Plus size={17}/> Tarefa</button></div><div className="kanban">{cols.map(([s,n])=><div className="kanCol" key={s}><div className="kanTitle"><b>{n}</b><span>{tasks.filter(t=>t.s===s).length}</span></div>{tasks.filter(t=>t.s===s).map(t=><div className="task" draggable onDragStart={e=>e.dataTransfer.setData('text/plain',String(t.id))} key={t.id}><div className="grab">⋮⋮</div><b>{t.t}</b><small>{s==='done'?'Concluída':'Planeada para a semana'}</small></div>)}<div className="drop" onDragOver={e=>e.preventDefault()} onDrop={e=>moveTask(Number(e.dataTransfer.getData('text/plain')),s)}>Largar aqui</div></div>)}</div></div>}

function Routines({spotify}){const r=[['07:15','Acordar + água','routine'],['07:30','Higiene + skincare','routine'],['08:10','Autocarro / comboio','transport'],['12:30','Almoço','routine'],['18:00','Ginásio / desporto','gym'],['19:30','Banho + skincare','routine'],['20:00','Jantar','routine'],['21:30','Planeamento + casal','leisure']];return <div className="sectionPage"><div className="sectionHead"><div><div className="eyebrow">ROTINAS</div><h1>O dia inteiro, pensado.</h1><p>Uma base prática para universidade, autocuidado, movimento e vida a dois.</p></div></div><div className="routineGrid">{r.map(([time,title,cat])=><div className="routineCard" key={time}><span className="timePill">{time}</span><div><b>{title}</b><small>{cat==='transport'?'Tempo de deslocação':cat==='gym'?'Energia + consistência':'Pequeno bloco da rotina'}</small></div></div>)}</div><div className="routineMusic"><Music2 size={18}/><div><b>Spotify automático por momento</b><span>Estudo, treino, manhã e noite.</span></div><div className="musicLinks"><button onClick={()=>window.open(spotify.study,'_blank')}>Estudo</button><button onClick={()=>window.open(spotify.gym,'_blank')}>Ginásio</button><button onClick={()=>window.open(spotify.morning,'_blank')}>Manhã</button></div></div></div>}
