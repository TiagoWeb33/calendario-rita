import './globals.css';
export const metadata = { title: 'Rita & Tiago — Weekly', description: 'Calendário partilhado para universidade, rotinas e vida.' };
export default function RootLayout({children}){ return <html lang="pt"><body>{children}</body></html>; }
